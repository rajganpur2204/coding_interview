-- Table: demo.charging_station

-- DROP TABLE IF EXISTS demo.charging_station;

CREATE TABLE IF NOT EXISTS demo.charging_station
(
    id integer NOT NULL,
    speed integer NOT NULL,
    state integer NOT NULL DEFAULT 0,
    charger_id integer NOT NULL DEFAULT 0,
    CONSTRAINT charging_station_pkey PRIMARY KEY (id)
)


-- Table: demo.charging_vehicle

-- DROP TABLE IF EXISTS demo.charging_vehicle;

CREATE TABLE IF NOT EXISTS demo.charging_vehicle
(
    id integer NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 MINVALUE 1 MAXVALUE 2147483647 CACHE 1 ),
    vehicle_id integer NOT NULL DEFAULT 0,
    charger_id integer NOT NULL DEFAULT 0,
    c_speed integer NOT NULL DEFAULT 0,
    percentage double precision NOT NULL DEFAULT 0,
    minutes integer NOT NULL DEFAULT 0,
    v_speed integer DEFAULT 0,
    CONSTRAINT charging_vehicle_pkey PRIMARY KEY (id)
)

-- Table: demo.power_grid

-- DROP TABLE IF EXISTS demo.power_grid;

CREATE TABLE IF NOT EXISTS demo.power_grid
(
    id integer NOT NULL,
    power_limit integer NOT NULL,
    CONSTRAINT power_grid_pkey PRIMARY KEY (id)
)

-- Table: demo.vehicle

-- DROP TABLE IF EXISTS demo.vehicle;

CREATE TABLE IF NOT EXISTS demo.vehicle
(
    id integer NOT NULL,
    capacity integer DEFAULT 50,
    max_charge_speed integer DEFAULT 50,
    CONSTRAINT vehicle_pkey PRIMARY KEY (id)
)