package com.camber.ev;

import java.util.List;

import com.camber.ev.core.Advancement;
import com.camber.ev.core.AdvancementImpl;
import com.camber.ev.core.Charging;
import com.camber.ev.core.ChargingImpl;
import com.camber.ev.exception.ChargerNotConnectedException;
import com.camber.ev.model.ChargingState;

public class ChargingManagementApplication {

	public static void main(String[] args) {

		if (args.length > 0) {
			System.out.println("Got parameters: " + args[0]);
			int chargerId;
			int vehicleId;
			int timeInteval;
			switch (args[0]) {
			case "connect":
				if (args.length == 3) {
					chargerId = Integer.parseInt(args[1]);
					vehicleId = Integer.parseInt(args[2]);
					System.out.printf("Got connection request to charge  " + "the Vehicle: %d with the Charger: %d \n",
							chargerId, vehicleId);
					try {
						Charging ch1 = new ChargingImpl();
						ch1.connect(chargerId, vehicleId);
					} catch (Exception e) {
						System.out.println("Exception " + e.getMessage());
					}
				} else {
					System.out.println(" please enter chargerId and vehicleId to connect");
				}

				break;
			case "disconnect":
				if (args.length == 2) {
					chargerId = Integer.parseInt(args[1]);
					System.out.printf("Got disconnect request to the " + "Charger: %d \n", chargerId);
					Charging ch1 = new ChargingImpl();
					try {
						ch1.disConnect(chargerId);
					} catch (ChargerNotConnectedException e) {
						System.out.println("Issue in disconnect...");
					}
				} else {
					System.out.println(" please enter chargerId to disconnect");
				}
				break;
			case "advance":
				if (args.length == 2) {
					timeInteval = Integer.parseInt(args[1]);
					System.out.printf("Got advance request with the " + "Time interval: %d ", timeInteval);
					Advancement adv = new AdvancementImpl();
					try {
						adv.advance(timeInteval);
					} catch (Exception e) {
						System.out.println("Issue in advance...");
					}
				} else {
					System.out.println(" please enter advance command and <minutes> to advace...");
				}

				break;
			case "state":
				System.out.println("Please find the below state of the system: ");
				Charging ch = new ChargingImpl();
				List<ChargingState> css = ch.getChargingState();
				if (css.size() > 0) {
					System.out.println("ChargerId  State     vehicleId  charging%");
					for (ChargingState cs : css) {
						System.out.printf("%d          %s 	 %d	  %s\n", cs.getChargerId(), cs.getState(),
								cs.getVehicleId(), cs.getChargingPercent());
					}
				} else {
					System.out.println("Unable to get the state information...");
				}

				break;
			default:
				System.out.println("Invalid option entered....");
				System.out.println("Please enter below options....");
				System.out.println(" connect <charger> <vehicle>\n " + "disconnect <charger>\n "
						+ "advance <minute-internals>\n " + "state\n");
			}

		} else {
			System.out.println("Please enter valid parameters..");
		}

	}

}
