package com.camber.ev.core;

import com.camber.ev.exception.FailedToAdvanceException;

public interface Advancement {
	
	void advance(int minutes) throws FailedToAdvanceException;

}
