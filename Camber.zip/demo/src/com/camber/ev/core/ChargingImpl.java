package com.camber.ev.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.camber.ev.exception.ChargerNotAvailableException;
import com.camber.ev.exception.ChargerNotConnectedException;
import com.camber.ev.model.ChargingState;

public class ChargingImpl implements Charging {

	private static final String CHARGING = "Charging";
	private static final String IDLE = "Idle";

	/**
	 * connect the charger to Vehicle
	 * 
	 * @param chargerId
	 * @param vehicleId
	 * @throws ChargerNotAvailableException
	 */
	@Override
	public void connect(int chargerId, int vehicleId) throws ChargerNotAvailableException {
		DBConnection dbConn = new PostgresDBConnection();
		Connection con = null;
		try {
			con = dbConn.getConnection();
			connectChargertoVehicle(con, chargerId, vehicleId);
		} catch (Exception e) {
			System.out.println("Exception in connect: " + e.getLocalizedMessage());
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Error in closing the DB connection");
			}
		}
	}

	/**
	 * connect the vehicle to charger
	 * 
	 * @param con
	 * @param chargerId
	 * @param vehicleId
	 * @throws ChargerNotAvailableException
	 */
	private void connectChargertoVehicle(Connection con, int chargerId, int vehicleId)
			throws ChargerNotAvailableException {
		try {
			if (!isChargerNotAvailable(con, chargerId)) {
				if (!exceedsPowerLimit(con, chargerId, vehicleId)) {
					if (isRecordExists(con, vehicleId)) {
						updateChargingVehicle(con, chargerId, vehicleId);
					} else {
						addToChargingVehicle(con, chargerId, vehicleId);
					}
					updateChargingState(con, chargerId);
					System.out.println("Vehicle is connected to Charger...");
				} else {
					System.out.println(
							"Vehicle cannot be charged as adding the is charger exeeds the power grid capacity limit. Please try after some time. ");
				}
			} else {
				System.out.println("Charger is not availabe to connect please try other charger");
			}

		} catch (Exception e) {
			System.out.println("Exception in update: " + e.getMessage());
		}

	}

	/**
	 * checks the load after adding the new charger to vehicle
	 * 
	 * @param con
	 * @param chargerId
	 * @param vehicleId
	 * @return
	 * @throws SQLException
	 */
	private boolean exceedsPowerLimit(Connection con, int chargerId, int vehicleId) throws SQLException {

		if (findTotalChargingLoad(con) + newLoadWith(con, chargerId, vehicleId) > getPowergridLimit(con)) {
			return true;
		}

		return false;
	}

	/**
	 * find out the new load after adding the charger to Vehicle
	 * 
	 * @param con
	 * @param chargerId
	 * @param vehicleId
	 * @return
	 */
	private int newLoadWith(Connection con, int chargerId, int vehicleId) throws SQLException {
		int vehicleCapacity = getVehicleCapacity(con, vehicleId);
		int chargerCapacity = getChargerCapacity(con, chargerId);
		return vehicleCapacity < chargerCapacity ? vehicleCapacity : chargerCapacity;
	}

	/**
	 * returns the vehicle capacity
	 * 
	 * @param con
	 * @param vehicleId
	 * @return
	 * @throws SQLException
	 */
	private int getVehicleCapacity(Connection con, int vehicleId) throws SQLException {
		PreparedStatement pst = con.prepareStatement("select id from demo.vehicle where id = ?");
		pst.setInt(1, vehicleId);
		ResultSet rs = pst.executeQuery();
		return null != rs ? rs.next() ? rs.getInt(1) : 0 : 0;
	}

	/**
	 * return charger capacity
	 * 
	 * @param con
	 * @param chargerId
	 * @return
	 * @throws SQLException
	 */
	private int getChargerCapacity(Connection con, int chargerId) throws SQLException {
		PreparedStatement pst = con.prepareStatement("select id from demo.charging_station where charger_id = ?");
		pst.setInt(1, chargerId);
		ResultSet rs = pst.executeQuery();
		return null != rs ? rs.next() ? rs.getInt(1) : 0 : 0;
	}

	/**
	 * Give the total charging load on the grid
	 * 
	 * @param con
	 * @return
	 * @throws SQLException
	 */
	private int findTotalChargingLoad(Connection con) throws SQLException {
		int totalLoad = 0;
		Statement pst1 = con.createStatement();
		ResultSet rs = pst1.executeQuery("select c_speed,v_speed from demo.charging_vehicle");
		int cSpeed, vSpeed;

		while (rs.next()) {
			cSpeed = rs.getInt(1);
			vSpeed = rs.getInt(2);
			if (cSpeed < vSpeed) {
				totalLoad += cSpeed;
			} else {
				totalLoad += vSpeed;
			}
		}
		return totalLoad;
	}

	/**
	 * updates the charging state
	 * 
	 * @param chargerId
	 */
	private void updateChargingState(Connection con, int chargerId) throws SQLException {
		PreparedStatement pst = con.prepareStatement("update demo.charging_station set state =1 where charger_id = ?");
		pst.setInt(1, chargerId);
		pst.executeUpdate();
		pst.close();

	}

	/**
	 * checks for the charger availability
	 * 
	 * @param con
	 * @param chargerId
	 * @return
	 */
	private boolean isChargerNotAvailable(Connection con, int chargerId) throws SQLException {
		PreparedStatement pst1 = con.prepareStatement("select state from demo.charging_station where charger_id = ?");
		pst1.setInt(1, chargerId);
		ResultSet rs = pst1.executeQuery();
		return null != rs ? rs.next() ? rs.getInt(1) == 1 ? true : false : false : false;
	}

	private int getPowergridLimit(Connection con) throws SQLException {
		Statement pst1 = con.createStatement();
		ResultSet rs = pst1.executeQuery("select power_limit from demo.power_grid");
		return null != rs ? rs.next() ? rs.getInt(1) : 0 : 0;
	}

	/**
	 * isRecordExists will check the mapping of the charger to any vehicle
	 * 
	 * @param con
	 * @param vehicleId
	 * @return
	 * @throws SQLException
	 */
	private boolean isRecordExists(Connection con, int vehicleId) throws SQLException {
		PreparedStatement pst = con.prepareStatement("select id from demo.charging_vehicle where vehicle_id = ?");
		pst.setInt(1, vehicleId);
		ResultSet rs = pst.executeQuery();
		return null != rs ? rs.next() ? true : false : false;
	}

	/**
	 * addToChargingVehicle is used to add to charging_vehicle
	 * 
	 * @param con
	 * @param chargerId
	 * @param vehicleId
	 * @throws SQLException
	 */
	private void addToChargingVehicle(Connection con, int chargerId, int vehicleId) throws SQLException {
		PreparedStatement pst = con.prepareStatement(
				"insert into demo.charging_vehicle(vehicle_id, charger_id, c_speed, percentage, minutes, v_speed) values(?,?,?,?,?,?)");
		pst.setInt(1, vehicleId);
		pst.setInt(2, chargerId);
		pst.setInt(3, findCSpeed(con, chargerId));
		pst.setInt(4, 0);
		pst.setInt(5, 0);
		pst.setInt(6, findVSpeed(con, vehicleId));
		pst.executeUpdate();
		pst.close();
	}

	/**
	 * findCSpeed is used to get the charger configured max speed
	 * 
	 * @param con
	 * @param chargerId
	 * @return
	 * @throws SQLException
	 */
	private int findCSpeed(Connection con, int chargerId) throws SQLException {
		PreparedStatement pst = con.prepareStatement("select speed from demo.charging_station where charger_id = ?");
		pst.setInt(1, chargerId);
		ResultSet rs = pst.executeQuery();
		int cSpeed = rs.next() ? rs.getInt(1) : 0;
		rs.close();
		pst.close();
		return cSpeed;
	}

	/**
	 * findVSpeed is used ti get the vehicle configured max speed
	 * 
	 * @param con
	 * @param vehicleId
	 * @return
	 * @throws SQLException
	 */
	private int findVSpeed(Connection con, int vehicleId) throws SQLException {
		PreparedStatement pst = con.prepareStatement("select max_charge_speed from demo.vehicle where id = ?");
		pst.setInt(1, vehicleId);
		ResultSet rs = pst.executeQuery();
		int vSpeed = rs.next() ? rs.getInt(1) : 0;
		rs.close();
		pst.close();
		return vSpeed;
	}

	/**
	 * Updates the charging vehicle info based on the Connect request
	 * 
	 * @param con
	 * @param chargerId
	 * @param vehicleId
	 * @throws SQLException
	 */
	private void updateChargingVehicle(Connection con, int chargerId, int vehicleId) throws SQLException {
		PreparedStatement pst = con
				.prepareStatement("update demo.charging_vehicle set  charger_id = ?, c_speed =?  where vehicle_id = ?");
		pst.setInt(1, chargerId);
		pst.setInt(2, findCSpeed(con, chargerId));
		pst.setInt(3, vehicleId);
		pst.executeUpdate();
		pst.close();
	}

	/**
	 * disconnects the charger from vehicle
	 */

	@Override
	public void disConnect(int chargerId) throws ChargerNotConnectedException {
		DBConnection dbConn = new PostgresDBConnection();
		Connection con = null;
		try {
			con = dbConn.getConnection();
			disConnectCharger(con, chargerId);
		} catch (Exception e) {
			System.out.println("Exception in connect: " + e.getMessage());
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Error in closing the DB connection");
			}
		}
	}

	/**
	 * removes the charger from the vehicle if it is connected
	 * 
	 * @param con
	 * @param chargerId
	 * @throws ChargerNotConnectedException
	 */
	private void disConnectCharger(Connection con, int chargerId) throws ChargerNotConnectedException {
		if (checkChargerConnected(con, chargerId)) {
			// charger is connected and process dis connection
			try {
				// find the vehicle where charger is connected 
				PreparedStatement pst = con
						.prepareStatement("select vehicle_id from demo.charging_vehicle where charger_id =?");
				pst.setInt(1, chargerId);
				ResultSet rs = pst.executeQuery();
				int vehicleId = null != rs ? rs.next() ? rs.getInt(1) : 0 : 0;
				
				//dis-connect the vehicle from charger
				PreparedStatement upst = con.prepareStatement(
						"update demo.charging_vehicle set charger_id=0 , c_speed=0 where vehicle_id  =?");
				upst.setInt(1, vehicleId);
				upst.executeUpdate();
				
				//update the charger status 
				
				PreparedStatement cupst = con.prepareStatement(
						"update demo.charging_station set  state=0 where charger_id  =?");
				cupst.setInt(1, chargerId);
				cupst.executeUpdate();
				
			} catch (Exception e) {
				System.out.println("Exception in  getChargingState: " + e.getMessage());
			} 
			System.out.println("Charger is dis-connected...");
		} else {
			System.out.println("Charger is not connected to dis-connect... ");
		}

	}

	/**
	 * check for the availability of the charger
	 * 
	 * @param con
	 * @param chargerId
	 * @return
	 * 
	 */
	private boolean checkChargerConnected(Connection con, int chargerId) {
		try {
			PreparedStatement pst = con.prepareStatement("select state from demo.charging_station where charger_id =?");
			pst.setInt(1, chargerId);
			ResultSet rs = pst.executeQuery();
			return null != rs ? rs.next() ? rs.getInt(1) == 1 : false : false;
		} catch (Exception e) {
			System.out.println("Exception in  getChargingState: " + e.getMessage());
		} 
		return false;
	}

	/**
	 * gives the state of the charging
	 */

	@Override
	public List<ChargingState> getChargingState() {
		List<ChargingState> states = new ArrayList<>();
		DBConnection dbConn = new PostgresDBConnection();
		Connection con = null;
		try {
			con = dbConn.getConnection();
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery(
					"select cs.id,cs.state, cv.vehicle_id, cv.percentage from demo.charging_station cs left join demo.charging_vehicle cv on cs.charger_id = cv.charger_id order by cs.charger_id");

			while (rs.next()) {
				ChargingState cs = new ChargingState();
				cs.setChargerId(rs.getInt(1));
				cs.setState(rs.getInt(2) == 0 ? IDLE : CHARGING);
				cs.setChargingPercent(rs.getFloat(4));
				cs.setVehicleId(rs.getInt(3));
				states.add(cs);
			}
		} catch (Exception e) {
			System.out.println("Exception in  getChargingState: " + e.getMessage());
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Error in closing the DB connection");
			}
		}
		return states;
	}

}
