package com.camber.ev.core;

import java.util.List;

import com.camber.ev.exception.ChargerNotAvailableException;
import com.camber.ev.exception.ChargerNotConnectedException;
import com.camber.ev.model.ChargingState;

public interface Charging {

	void connect(int chargerId, int vehicleId) throws ChargerNotAvailableException;
	
	void disConnect(int chargerId) throws ChargerNotConnectedException;
	
	List<ChargingState> getChargingState();
}
