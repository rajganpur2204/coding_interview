package com.camber.ev.core;

import java.sql.Connection;

public interface DBConnection {

	Connection getConnection(); 
	
}
