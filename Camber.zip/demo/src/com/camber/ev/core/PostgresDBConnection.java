package com.camber.ev.core;

import java.sql.Connection;
import java.sql.DriverManager;

public class PostgresDBConnection implements DBConnection{

	@Override
	public Connection getConnection() {
		Connection c = null;
	      try {
	         Class.forName("org.postgresql.Driver");
	         c = DriverManager
	            .getConnection("jdbc:postgresql://localhost:5432/camber",
	            "postgres", "postgres");
	         
	      } catch (Exception e) {
	         System.out.println("Error in opening the DB connection: "+e.getMessage());
	      }
	     // System.out.println("Opened database successfully");
	      return c;
	}

}
