package com.camber.ev.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.camber.ev.exception.FailedToAdvanceException;
import com.camber.ev.model.ChargingStation;

public class AdvancementImpl implements Advancement {

	@Override
	public void advance(int minutes) throws FailedToAdvanceException {
		DBConnection dbConn = new PostgresDBConnection();
		try {
			Connection con = dbConn.getConnection();
			List<ChargingStation> stations = getActiveChargingStations();
			Map<Integer,Integer> capMap = getVehicleCapacity(con);
			PreparedStatement pstmt = con
					.prepareStatement("update demo.charging_vehicle set percentage =? , minutes = ? where id=?");
			for (ChargingStation cs : stations) {
				pstmt.setFloat(1, computeChargingPercentage(cs.getChargingPercent(), minutes, capMap, cs.getSpeed(), cs.getVehicleId()) );
				pstmt.setInt(2, cs.getMinutes() + minutes);
				pstmt.setInt(3, cs.getId());
				pstmt.addBatch();
			}
			pstmt.executeBatch();

		} catch (Exception e) {
			System.out.println("Issue in batch update.......");
		}

	}
	
	private float computeChargingPercentage(float oldPercent, int minutes, Map<Integer,Integer> capMap, int speed, int vehicleId) { 
		float percentage = 0;
		percentage = oldPercent + ((float)(minutes * capMap.get(vehicleId)) / (float)(speed * 60 )) * 100   ;  // 1 * 50 / 50 * 60 
		return percentage; 
	}

	private Map<Integer, Integer> getVehicleCapacity(Connection con)  {
		Map<Integer, Integer> capMap = new HashMap<>();
			try { 
				Statement st = con.createStatement();
				ResultSet rs = st.executeQuery(
						"select id, capacity from demo.vehicle");
				while (rs.next()) {
					capMap.put(rs.getInt(1), rs.getInt(2));
				}
			} catch (Exception e) { 
				System.out.println("exception in getting the vehicle map");
			}
		return capMap;
	}

	private List<ChargingStation> getActiveChargingStations() {
		List<ChargingStation> stations = new ArrayList<>();
		DBConnection dbConn = new PostgresDBConnection();
		Connection con = null;
		try {
			con = dbConn.getConnection();
			Statement st = con.createStatement();
			int cSpeed,vSpeed;
			ResultSet rs = st.executeQuery(
					"select cv.id, cv.vehicle_id,cs.state, cv.percentage,cv.vehicle_id, cv.minutes, cv.c_speed,cv.v_speed from demo.charging_station cs left join demo.charging_vehicle cv on cs.charger_id = cv.charger_id where cs.state=1");
			while (rs.next()) {
				ChargingStation cs = new ChargingStation();
				cs.setId(rs.getInt(1));
				cs.setChargerId(rs.getInt(2));
				cs.setState(rs.getInt(3));
				cs.setChargingPercent(rs.getInt(4));
				cs.setVehicleId(rs.getInt(5));
				cs.setMinutes(rs.getInt(6));
				cSpeed = rs.getInt(7);
				vSpeed = rs.getInt(8);
				cs.setSpeed( cSpeed<vSpeed ? cSpeed : vSpeed);
				stations.add(cs);
			}
		} catch (Exception e) {
			System.out.println("Exception in  getChargingState: " + e.getMessage());
		} finally {
			try {
				con.close();
			} catch (SQLException e) {
				System.out.println("Error in closing the DB connection");
			}
		}
		return stations;
	}

}
