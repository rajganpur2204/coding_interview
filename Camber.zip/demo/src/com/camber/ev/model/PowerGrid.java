package com.camber.ev.model;

public class PowerGrid {
	
	/**
	 * Current power limit for the whole grid, can change based on time of day (measured in kilowatts/kW)
	 */
	
	private int currentPowerLimit;

	public int getCurrentPowerLimit() {
		return currentPowerLimit;
	}

	public void setCurrentPowerLimit(int currentPowerLimit) {
		this.currentPowerLimit = currentPowerLimit;
	}

}
