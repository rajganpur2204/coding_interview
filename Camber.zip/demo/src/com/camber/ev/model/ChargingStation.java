package com.camber.ev.model;

public class ChargingStation {
	
	private int id; 
	private int chargerId;
	private int state;
	private int vehicleId; 
	private float chargingPercent;
	private int minutes;
	private int speed;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getChargerId() {
		return chargerId;
	}
	public void setChargerId(int chargerId) {
		this.chargerId = chargerId;
	}
	public int getState() {
		return state;
	}
	public void setState(int state) {
		this.state = state;
	}
	public int getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public float getChargingPercent() {
		return chargingPercent;
	}
	public void setChargingPercent(float chargingPercent) {
		this.chargingPercent = chargingPercent;
	}
	public int getMinutes() {
		return minutes;
	}
	public void setMinutes(int minutes) {
		this.minutes = minutes;
	}
	public int getSpeed() {
		return speed;
	}
	public void setSpeed(int speed) {
		this.speed = speed;
	}
	
	
	
}
