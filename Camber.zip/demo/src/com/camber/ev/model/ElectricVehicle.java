package com.camber.ev.model;


public class ElectricVehicle {
	
	/*
	 * unique identifer of a vehicle 
	 */
	private int vehicleId;
	/*
	 * total capacity (measured in kilowatt-hours/kWh)
	 */
	private int totalCapacity; 
	
	/*
	 * current state of charge (how much capacity is used/available in kilowatt-hours/kWh)
	 */
	private int currentStateOfCharge;
	
	/*
	 * maximum charging speed (measured in kilowatts/kW)
	 */
	private int maximumChargingSpeed;
	
	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public int getTotalCapacity() {
		return totalCapacity;
	}

	public void setTotalCapacity(int totalCapacity) {
		this.totalCapacity = totalCapacity;
	}

	public int getCurrentStateOfCharge() {
		return currentStateOfCharge;
	}

	public void setCurrentStateOfCharge(int currentStateOfCharge) {
		this.currentStateOfCharge = currentStateOfCharge;
	}

	public int getMaximumChargingSpeed() {
		return maximumChargingSpeed;
	}

	public void setMaximumChargingSpeed(int maximumChargingSpeed) {
		this.maximumChargingSpeed = maximumChargingSpeed;
	}
	
	

}
