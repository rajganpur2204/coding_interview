package com.camber.ev.model;

public class ChargingState {
	
	private int chargerId;
	private String state;
	private int vehicleId; 
	private float chargingPercent;
	public int getChargerId() {
		return chargerId;
	}
	public void setChargerId(int chargerId) {
		this.chargerId = chargerId;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	public int getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}
	public float getChargingPercent() {
		return chargingPercent;
	}
	public void setChargingPercent(float chargingPercent) {
		this.chargingPercent = chargingPercent;
	}
	
}
