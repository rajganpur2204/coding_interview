package com.camber.ev.model;

public class ElectricVehicleCharger {
	
	/*
	 * unique identfier of charger
	 */
	private int chargerId;
	/*
	 * Maximum charging speed (measured in kilowatts/kW)
	 */
	private int maximumChargingSpeed;
	
	public int getChargerId() {
		return chargerId;
	}
	public void setChargerId(int chargerId) {
		this.chargerId = chargerId;
	}
	public int getMaximumChargingSpeed() {
		return maximumChargingSpeed;
	}
	public void setMaximumChargingSpeed(int maximumChargingSpeed) {
		this.maximumChargingSpeed = maximumChargingSpeed;
	}
	
	

}
