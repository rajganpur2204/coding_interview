package com.camber.ev.exception;

public class ChargerNotConnectedException extends Exception {
	

	private static final long serialVersionUID = -2819146440465054252L;

	public ChargerNotConnectedException(String message) {
		super(message);
	}

}
