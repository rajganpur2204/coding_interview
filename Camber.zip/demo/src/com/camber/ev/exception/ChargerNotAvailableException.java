package com.camber.ev.exception;

public class ChargerNotAvailableException extends Exception {
	
	private static final long serialVersionUID = 320911987204357931L;

	public ChargerNotAvailableException(String message) {
		super(message);
	}

}
