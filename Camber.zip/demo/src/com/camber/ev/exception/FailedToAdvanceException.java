package com.camber.ev.exception;

public class FailedToAdvanceException extends Exception {

	private static final long serialVersionUID = 7049298615294822450L;
	
	public FailedToAdvanceException(String message) {
		super(message);
	}

}
